import { useEffect, useState } from "react"
import { Link } from "react-router-dom";
import "./styles/recipeList.css"

const RecipeListComponent = () => {
    const [recipes, setRecipes]= useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(()=> {
        const fetchRecipes = async () => {
            try {
                const response = await fetch("http://localhost:3003/allrecipe");
                const data = await response.json();
                setRecipes(data);
                setLoading(false);
            } catch (error) {
                console.error("Error fetching recipes:", error);
                setError("Error lors de la récupération des recettes.");
                setLoading(false);
            }
        };

        fetchRecipes();
    }, []);

    return (
        <>
        <div className="recipe-list-container">
            <h1 className="recipe-list-title">Liste des recettes</h1>
            {loading && <p>Chargement des recettes...</p>}
            {error && <p className="message-error">{error}</p>}
            {recipes.length > 0 ? (
                recipes.map((recipe) => (
                    <div key={recipe._id} className="recipe-card">
                    <img
                            className="recipe-image"
                            src={recipe.image || "https://via.placeholder.com/300"}
                            alt={recipe.title}
                        />
                    <h2 className="recipe-title">Titre de la recette : {recipe.title}</h2>
                    {/* Description de la recette */}
                    <p className="recipe-description">Description de la recette :  {recipe.description.substring(0, 100)}...</p>
                    <p className="recipe-temps">Temps de preparation : {recipe.tempsPreparation}</p>
                    <p className="recipe-nbrPortions">Nombre de portions : {recipe.nbrPortions}</p>

                    <Link to={`/recipe/${recipe._id}`} className="recipe-link">Voir la recette</Link>
                    </div>
                ))
            ) : (
                <p>Aucune recette disponible.</p>
            )}


                    
        </div>
        </>
    )
}

export default RecipeListComponent