import './styles/footer.css'
const FooterConponent = () => {
    return (
        <>
        <footer>
            <nav>
                <p>© 2024 Nihel Ben Mahfoudh</p>
                <ul>
                    <li>Mentions Légales</li>
                </ul>
            </nav>
        </footer>

        </>
    )
}

export default FooterConponent
