import { Link } from 'react-router-dom'
import './styles/header.css'
const HeaderComponenet = () => {
    
    return (
        <>
            <header className="App-header">
                <div className="App-logo" >
                    Recettes en or
                </div>
                <nav className="App-nav">
                    <ul className="nav-list">
                        <li> <Link to={"/"}>Accueil</Link></li>
                        <li> <Link to={"/addrecipe"}>Ajouter une recette</Link></li>
                        <li> <Link to={"/favoris"}> Favoris</Link></li>
                    </ul>
                </nav>
                <div className="App-search">
                    <input type="text" placeholder="Rechercher une recette" />
                </div>
            </header>

        </>
    )
}

export default HeaderComponenet