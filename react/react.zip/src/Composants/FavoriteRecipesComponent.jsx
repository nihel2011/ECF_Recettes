const FavoriteRecipeComponent = () => {
    return (
        <>
            
        </>
    )
    
}

export default FavoriteRecipeComponent